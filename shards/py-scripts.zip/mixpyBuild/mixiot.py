from paho.mqtt import client as mqtt_client
import requests

class MixIO:
    
    HELLO = 'b640a0ce465fa2a4150c36b305c1c11b'
    BYE = '9d634e1a156dc0c1611eb4c3cff57276'
    PUBLIC_USER = 'MixIO_public'
    
    def __init__(self, broker, port, username, password, project, client_id):
        self.broker = broker
        self.port = port
        self.username = username
        self.password = password
        self.project = project
        self.client_id = client_id
        self.client = mqtt_client.Client(client_id)
        if self.username != MixIO.PUBLIC_USER:
            self.client.will_set(f'{username}/{project}/{MixIO.BYE}', client_id)
        self.client.username_pw_set(username, password)
        self.client.on_connect = self.on_connect
        self.callbacks = []
        self.client.on_message = self.on_message

    @classmethod
    def from_mixly_key(cls, broker, port, mixly_key, client_id):
        username = MixIO.PUBLIC_USER
        password = MixIO.PUBLIC_USER
        project = mixly_key
        return cls(broker, port, username, password, project, client_id)
    
    @classmethod
    def from_share_key(cls, broker, port, share_key, client_id):
        url = f'https://mixio.mixly.cn/mixio-php/sharekey.php?sk={share_key}'
        r = requests.get(url)
        if r.status_code == 200:
            if r.text == "-1":
                raise Exception("share key error")
            else:
                jsonR = r.json()
                username = jsonR['userName']
                password = jsonR['projectPass']
                project = jsonR['projectName']
                return cls(broker, port, username, password, project, client_id)
    
    def on_message(self, client, userdata, msg):
        topic = msg.topic.split('/')[-1]
        payload = msg.payload.decode()
        for callback in self.callbacks:
            if callback['topic'] == topic:
                callback['callback'](client, topic, payload)
    
    def connect(self):
        self.client.connect(self.broker, self.port, keepalive=60)
        self.client.loop() 
   
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            if self.username != MixIO.PUBLIC_USER:
                client.publish(f'{self.username}/{self.project}/{MixIO.HELLO}', self.client_id)
            print("Connected to MixIO!")
        else:
            print("Failed to connect, return code ", rc)
    
    def publish(self, topic, payload):
        if self.username != MixIO.PUBLIC_USER:
            self.client.publish(f'{self.username}/{self.project}/{topic}', payload)
        else:
            self.client.publish(f'MixIO/{self.project}/default/{topic}', payload)
    
    def subscribe_and_set_callback(self, topic, callback):
        if self.username != MixIO.PUBLIC_USER:
            self.client.subscribe(f'{self.username}/{self.project}/{topic}')
            self.callbacks.append({'topic': topic, 'callback': callback})
        else:
            self.client.subscribe(f'MixIO/{self.project}/default/{topic}')
            self.callbacks.append({'topic': topic, 'callback': callback})
        
    def unsubscribe(self, topic):
        if self.username != MixIO.PUBLIC_USER:
            self.client.unsubscribe(f'{self.username}/{self.project}/{topic}')
        else:
            self.client.unsubscribe(f'MixIO/{self.project}/default/{topic}')

    def check_msg(self):
        self.client.loop()

    def disconnect(self):
        if self.username != MixIO.PUBLIC_USER:
            self.client.publish(f'{self.username}/{self.project}/{MixIO.BYE}', self.client_id)
        self.client.disconnect()