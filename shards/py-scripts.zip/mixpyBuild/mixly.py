import time


print('Hello', 'Mixly')
for _my_variable in range(10):
    print('Hello')
    time.sleep(2)
